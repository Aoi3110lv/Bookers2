# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '747dbecb141152341f2e3cdf3059716203e368fba606891fc9aa89b0fbbdf0af3c9c5d67e818398cc22bc701eab56bb11b1d31fbd3ebf4d01e54d581ae759ce0'